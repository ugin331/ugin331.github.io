                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:3472634
Anvil Hawk Model Kit - Star Citizen by JosephWan is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

This is a 1/100 model kit of the Anvil Hawk from the up-coming space game Star Citizen. The kit is designed to be printing / painting friendly and tolerances have been added for quick assemble. The ship can switch between landing and flying mode by implementing joints and changing the landing gear parts. 

With 44 parts in total, I assume there will be difficulty when putting it together. Please feel free to let me know in the comment section if you have any problems. I will keep polishing the models or maybe put together an instruction book in the future.

Hope you enjoy it.

* Files with (BETA) on it's name are new STL files outputted from the 3D software that have never been test printed. They might not work as intended.

* Weapon set has not been build this time

* The model does not come with LTI. Please don't fly it into the sun.

//This model are Made by the Star Citizen Community
//Star Citizen®, Roberts Space Industries® and Cloud Imperium ® are registered trademarks of Cloud Imperium Rights LLC

# Print Settings

Printer Brand: Anycubic
Printer: All-metal Mega
Rafts: Yes
Supports: Yes
Resolution: 0.1/0.2
Infill: 15%
Filament_brand: -
Filament_color: White
Filament_material: PLA

Notes: 
0.8 mm wall thickness are used in most of the parts. 3D printer with heat bed is also recommenced. Deforming parts are the main cause of failure in this build.

# How I Designed This

## Summery

Most of the 3D printable models for Star Citizen are extracted from game files or taken from the RSI website. The Resolution of the files are usually fairly low and require tons of repairing before printing. Parts separation of those models are difficult and doing that will usually result in non-natural parting lines. That is the reason why I created this model kit from scratch. First of all I take photos of the front view, side view and top view of the ship and put them into Solidworks with the correct scale. Using project curve and different surface commends, I am able to create different parts of the ship separately. Tolerance are added to each joints by test printing and multiple try and error process. 

# Custom Section

## List

Things that you might need to buy before making the kit:
i.Plastic beams ( tamiya polystyrene beams) 4mm in diameter x 2
ii.Super glue
iii.Cutter
iV.Filler primer

Components list:
1.Stand
2.(BETA)Bounty Cell (Landing Gear Cover)
3.(BETA)Left Landing Gear
4.(BETA)Right Landing Gear
5.Bounty Cell (Bed)
6.Bounty Cell (Body)
7.Bounty Cell (Connector Thruster)
8.Bounty Cell (Connector)
9.Bounty Cell (Door)
10.Left Engine 1 (Intake)
11.Left Engine 1
12.Left Engine 2 (Joint)
13.Left Engine 2 (Secondary Thruster)
14.Left Engine 2
15.Left Main Wing (joint)
16.Left Main Wing (Landing Gear Cover 1)
17.Left Main Wing (Landing Gear Cover 2)
18.Left Main Wing (Tips)
19.Left Main Wing
20.Left Secondary Wing (Joint)
21.Left Secondary Wing (Weapon Disk 1)
22.Left Secondary Wing (Weapon Disk 2)
23.Left Secondary Wing (Weaponary Casing)
24.Left Secondary Wing
25.Right Engine 1 (Intake)
26.Right Engine 1
27.Right Engine 2 (Joint)
28.Right Engine 2 (Secondary Thruster)
29.Right Engine 2 
30.Right Main Wing (joint)
31.Right Main Wing (Landing Gear Cover 1)
32.Right Main Wing (Landing Gear Cover 2)
33.Right Main Wing (Tips)
34.Right Main Wing
35.Right Secondary Wing (Joint)
36.Right Secondary Wing (Weapon Disk 1)
37.Right Secondary Wing (Weapon Disk 2)
38.Right Secondary Wing (Weaponary Casing)
39.Right Secondary Wing
40.Ship Body (Door)
41.Ship Body (EMP)
42.Ship Body (Lower)
43.Ship Body (Upper)
44.Ship Body (Wind Shield)